package com.rizqai.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(16,13,27), panel=Color.rgb(30,25,47);
    private final int purple=Color.rgb(167,139,250), white=Color.WHITE, muted=Color.rgb(190,184,208);
    private EditText business, product, offer;
    private TextView output, footer;
    private int generated=0;

    @Override public void onCreate(Bundle b) { super.onCreate(b); buildUI(); }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    private LinearLayout column() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private void space(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    private EditText field(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setTextColor(white);
        e.setHintTextColor(muted); e.setHint(hint); e.setPadding(16,8,16,8); e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        e.setBackground(shape(Color.rgb(40,34,59),18)); e.setTextDirection(View.TEXT_DIRECTION_RTL); return e;
    }
    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextColor(white); b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(shape(Color.rgb(106,76,190),18)); return b;
    }
    private void buildUI() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout root=column(); root.setPadding(20,24,20,28); scroll.addView(root); setContentView(scroll);
        TextView logo=text("رزق AI ✦",30,white,true); logo.setGravity(Gravity.CENTER); root.addView(logo,lp(-1,-2));
        TextView sub=text("مساعدك الذكي لصناعة محتوى يبيع",15,purple,true); sub.setGravity(Gravity.CENTER); root.addView(sub,lp(-1,-2));
        space(root,20);
        LinearLayout intro=column(); intro.setPadding(16,14,16,14); intro.setBackground(shape(panel,20));
        intro.addView(text("ابدأ بوستك في ثواني",18,white,true)); space(intro,6);
        intro.addView(text("اكتب تفاصيل نشاطك، وجهّز نصًا تسويقيًا تقدر تنسخه وتعدله.",13,muted,false));
        root.addView(intro,lp(-1,-2)); space(root,18);

        root.addView(text("نوع النشاط أو المحل",14,white,true),lp(-1,-2)); space(root,6);
        business=field("مثال: محل ملابس، مطعم، صالون"); root.addView(business,lp(-1,52)); space(root,12);
        root.addView(text("المنتج أو الخدمة",14,white,true),lp(-1,-2)); space(root,6);
        product=field("مثال: تيشيرتات قطن"); root.addView(product,lp(-1,52)); space(root,12);
        root.addView(text("السعر أو العرض (اختياري)",14,white,true),lp(-1,-2)); space(root,6);
        offer=field("مثال: 250 جنيه أو خصم 20%"); root.addView(offer,lp(-1,52)); space(root,16);

        Button gen=button("✨ إنشاء إعلان"); root.addView(gen,lp(-1,54)); gen.setOnClickListener(v->generate(false));
        space(root,10); Button video=button("🎬 أفكار لفيديو قصير"); video.setBackground(shape(Color.rgb(61,52,84),18));
        root.addView(video,lp(-1,50)); video.setOnClickListener(v->generate(true)); space(root,18);

        LinearLayout card=column(); card.setPadding(16,16,16,16); card.setBackground(shape(panel,20));
        card.addView(text("النتيجة",18,white,true)); space(card,10);
        output=text("إعلانك هيظهر هنا بعد ما تضغط إنشاء إعلان.",15,muted,false); output.setTextIsSelectable(true); card.addView(output,lp(-1,-2));
        space(card,12); Button copy=button("📋 نسخ النص"); card.addView(copy,lp(-1,48));
        copy.setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Rizq AI",output.getText().toString())); Toast.makeText(this,"تم نسخ النص",Toast.LENGTH_SHORT).show();});
        root.addView(card,lp(-1,-2)); space(root,16);
        footer=text("نسخة أولية تجريبية • تعمل دون إنترنت • راجع النص قبل النشر",12,muted,false);
        footer.setGravity(Gravity.CENTER); root.addView(footer,lp(-1,-2));
    }
    private void generate(boolean video) {
        String b=business.getText().toString().trim(), p=product.getText().toString().trim(), o=offer.getText().toString().trim();
        if(b.isEmpty()||p.isEmpty()){Toast.makeText(this,"اكتب نوع النشاط والمنتج أولًا",Toast.LENGTH_SHORT).show();return;}
        String result;
        if(video) {
            result="🎬 فكرة فيديو مدته 15 ثانية\n\n0–3 ثوانٍ: لقطة جذابة للمنتج "+p+" مع سؤال يشد الانتباه.\n\n"+
            "3–8 ثوانٍ: اعرض المنتج من أكثر من زاوية واذكر ميزة حقيقية.\n\n"+
            "8–12 ثانية: وضّح السعر أو العرض إن وجد"+(o.isEmpty()?"":" ("+o+")")+".\n\n"+
            "12–15 ثانية: اختم بدعوة للتواصل مع "+b+".\n\nنصيحة: استخدم صورًا حقيقية ولا تذكر مزايا غير مؤكدة.";
        } else {
            result="🔥 عرض مميز من "+b+"!\n\nبتدور على "+p+"؟ 👌\n"+
            "جهزنالك اختيار يستاهل التجربة، بجودة واهتمام بالتفاصيل."+
            (o.isEmpty()?"":"\n🎁 العرض: "+o)+"\n\n📩 ابعتلنا رسالة لمعرفة التفاصيل والطلب.\n✨ مستنيينك!\n\n#"+tag(b)+" #عروض #تسوق";
        }
        output.setText(result); output.setTextColor(white); generated++;
        footer.setText("تم إعداد "+generated+" نصوص محليًا • نسخة تجريبية دون اتصال");
    }
    private String tag(String s){String t=s.replaceAll("[^\\p{L}\\p{N}]","");return t.isEmpty()?"مشروعك":t;}
}
